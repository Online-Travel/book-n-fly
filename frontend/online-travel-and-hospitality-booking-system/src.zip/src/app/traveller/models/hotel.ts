export interface Hotel {
    hotelId: number;
    name: string;
    location: string;
    roomsAvailable: number;
    rating: number;
    pricePerNight: number;
}
